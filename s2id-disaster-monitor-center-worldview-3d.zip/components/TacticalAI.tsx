import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, Terminal, Sparkles, RefreshCw } from 'lucide-react';
import { chatWithAI } from '../services/geminiService';
import { DisasterDecree } from '../types';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

interface TacticalAIProps {
  context: DisasterDecree[];
}

const TacticalAI: React.FC<TacticalAIProps> = ({ context }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{
        id: 'ai-init',
        role: 'assistant',
        text: 'SAUDAÇÕES, OPERADOR. SOU O ORÁCULO TÁTICO S2ID. COMO POSSO AUXILIAR NA ANÁLISE DE DADOS HOJE?',
        timestamp: new Date().toLocaleTimeString()
      }]);
    }
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await chatWithAI(input, context);
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        text: response,
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-tactical-panel border border-tactical-border relative overflow-hidden">
      <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-tactical-green"></div>
      <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-tactical-green"></div>
      
      <div className="p-3 border-b border-tactical-border bg-black/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="w-4 h-4 text-tactical-green" />
          <h3 className="text-[10px] font-mono uppercase tracking-widest text-tactical-green">AI Tactical Oracle</h3>
        </div>
        <div className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-tactical-green animate-pulse" />
            <span className="text-[8px] font-mono text-tactical-green uppercase">Neural Link Active</span>
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="flex-grow overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-tactical-border bg-[radial-gradient(circle_at_center,rgba(0,255,65,0.03)_0%,transparent_70%)]"
      >
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.role === 'assistant' ? 'items-start' : 'items-end'}`}>
            <div className="flex items-center gap-2 mb-1">
              <span className={`text-[9px] font-bold font-mono ${msg.role === 'assistant' ? 'text-tactical-green' : 'text-tactical-blue'}`}>
                [{msg.role === 'assistant' ? 'ORACLE' : 'OPERATOR'}]
              </span>
              <span className="text-[8px] font-mono text-tactical-muted">{msg.timestamp}</span>
            </div>
            <div className={`max-w-[90%] p-2 border ${msg.role === 'assistant' ? 'border-tactical-green/30 bg-tactical-green/5 text-tactical-green' : 'border-tactical-blue/30 bg-tactical-blue/5 text-tactical-blue'} font-mono text-xs leading-relaxed whitespace-pre-wrap`}>
              {msg.role === 'assistant' ? `${">"} ` : ''}{msg.text}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex items-center gap-2 text-tactical-green animate-pulse font-mono text-[10px]">
            <RefreshCw className="w-3 h-3 animate-spin" />
            <span>PROCESSANDO CONSULTA...</span>
          </div>
        )}
      </div>

      <div className="p-3 border-t border-tactical-border bg-black/30">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="CONSULTAR ORÁCULO..."
            className="flex-grow bg-black border border-tactical-border px-3 py-2 text-xs font-mono text-tactical-green focus:outline-none focus:border-tactical-green/50 placeholder:text-tactical-muted"
          />
          <button 
            onClick={handleSend}
            disabled={isTyping}
            className="bg-tactical-green/10 border border-tactical-green text-tactical-green p-2 hover:bg-tactical-green hover:text-black transition-all disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default TacticalAI;
