import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { Send, User, Terminal, MessageSquare } from 'lucide-react';

interface Message {
  id: string;
  user: string;
  text: string;
  timestamp: string;
  type: 'operator' | 'system';
}

const TacticalChat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const socketRef = useRef<Socket | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    socketRef.current = io();

    socketRef.current.on('receive_message', (message: Message) => {
      setMessages((prev) => [...prev, message]);
    });

    // Initial system message
    setMessages([{
      id: 'sys-1',
      user: 'SYSTEM',
      text: 'CONEXÃO ESTABELECIDA COM O CANAL TÁTICO.',
      timestamp: new Date().toLocaleTimeString(),
      type: 'system'
    }]);

    return () => {
      socketRef.current?.disconnect();
    };
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    socketRef.current?.emit('send_message', {
      user: 'OPERADOR_' + socketRef.current.id?.substr(0, 4).toUpperCase(),
      text: input,
      type: 'operator'
    });
    setInput('');
  };

  return (
    <div className="flex flex-col h-full bg-tactical-panel border border-tactical-border relative">
      <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-tactical-blue"></div>
      <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-tactical-blue"></div>
      
      <div className="p-3 border-b border-tactical-border bg-black/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-tactical-blue" />
          <h3 className="text-[10px] font-mono uppercase tracking-widest text-tactical-blue">Canal de Comunicação</h3>
        </div>
        <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-tactical-green animate-pulse"></span>
            <span className="text-[8px] font-mono text-tactical-green uppercase">Encrypted</span>
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="flex-grow overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-tactical-border"
      >
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.type === 'system' ? 'items-center' : ''}`}>
            <div className="flex items-center gap-2 mb-1">
              <span className={`text-[9px] font-bold font-mono ${msg.type === 'system' ? 'text-tactical-blue' : 'text-tactical-green'}`}>
                [{msg.user}]
              </span>
              <span className="text-[8px] font-mono text-tactical-muted">{msg.timestamp}</span>
            </div>
            <p className={`text-xs font-mono leading-relaxed ${msg.type === 'system' ? 'text-tactical-blue/80 italic text-center' : 'text-tactical-text'}`}>
              {msg.type === 'operator' ? `${">"} ` : ''}{msg.text}
            </p>
          </div>
        ))}
      </div>

      <div className="p-3 border-t border-tactical-border bg-black/30">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="DIGITE SUA MENSAGEM..."
            className="flex-grow bg-black border border-tactical-border px-3 py-2 text-xs font-mono text-tactical-green focus:outline-none focus:border-tactical-green/50 placeholder:text-tactical-muted"
          />
          <button 
            onClick={handleSend}
            className="bg-tactical-blue/10 border border-tactical-blue text-tactical-blue p-2 hover:bg-tactical-blue hover:text-black transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default TacticalChat;
