import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { DisasterDecree } from '../types';

interface GlobeProps {
  data: DisasterDecree[];
  onPointClick?: (point: DisasterDecree) => void;
}

const Globe: React.FC<GlobeProps> = ({ data, onPointClick }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [rotation, setRotation] = useState<[number, number]>([0, 0]);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = 600;
    const height = 600;
    const sensitivity = 75;

    const svg = d3.select(svgRef.current)
      .attr('width', '100%')
      .attr('height', '100%')
      .attr('viewBox', `0 0 ${width} ${height}`);

    svg.selectAll('*').remove();

    const projection = d3.geoOrthographic()
      .scale(250)
      .center([0, 0])
      .rotate([-rotation[0], -rotation[1]])
      .translate([width / 2, height / 2]);

    const initialScale = projection.scale();
    const path = d3.geoPath().projection(projection);

    // Globe background
    svg.append('circle')
      .attr('fill', '#050505')
      .attr('stroke', '#1f2937')
      .attr('stroke-width', '1')
      .attr('cx', width / 2)
      .attr('cy', height / 2)
      .attr('r', initialScale);

    // Graticule
    const graticule = d3.geoGraticule();
    svg.append('path')
      .datum(graticule())
      .attr('class', 'graticule')
      .attr('d', path as any)
      .attr('fill', 'none')
      .attr('stroke', '#1f2937')
      .attr('stroke-width', '0.5')
      .attr('opacity', 0.5);

    // Load World Data (Simplified)
    d3.json('https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson').then((worldData: any) => {
      svg.append('g')
        .selectAll('path')
        .data(worldData.features)
        .enter()
        .append('path')
        .attr('d', path as any)
        .attr('fill', '#0a0a0a')
        .attr('stroke', '#1f2937')
        .attr('stroke-width', '0.5');

      // Points
      const points = svg.append('g');
      
      // Simulated coordinates for Brazil states if not provided
      // In a real app, we'd have a mapping of municipality to lat/lng
      const getCoords = (uf: string): [number, number] => {
        const mapping: Record<string, [number, number]> = {
          'SC': [-50, -27], 'RS': [-52, -30], 'PR': [-51, -25],
          'SP': [-46, -23], 'RJ': [-43, -22], 'MG': [-44, -18],
          'BA': [-41, -12], 'PE': [-37, -8], 'CE': [-39, -5],
          'AM': [-63, -3], 'PA': [-52, -3], 'MT': [-55, -13],
          'GO': [-49, -16], 'MS': [-54, -20], 'ES': [-40, -19],
          'RN': [-36, -5], 'PB': [-36, -7], 'AL': [-36, -9],
          'SE': [-37, -10], 'PI': [-42, -7], 'MA': [-45, -5],
          'TO': [-48, -10], 'RO': [-63, -11], 'AC': [-70, -9],
          'RR': [-61, 2], 'AP': [-51, 1], 'DF': [-47, -15]
        };
        return mapping[uf] || [-47, -15];
      };

      data.forEach(d => {
        const coords = getCoords(d.uf);
        const projected = projection(coords);
        
        if (projected) {
          const g = points.append('g')
            .attr('class', 'point')
            .style('cursor', 'pointer')
            .on('click', () => onPointClick?.(d));

          // Outer glow
          g.append('circle')
            .attr('cx', projected[0])
            .attr('cy', projected[1])
            .attr('r', 8)
            .attr('fill', d.type.includes('Inundação') || d.type.includes('Enxurrada') ? '#00f0ff' : '#ffb000')
            .attr('opacity', 0.2)
            .append('animate')
            .attr('attributeName', 'r')
            .attr('values', '4;12;4')
            .attr('dur', '2s')
            .attr('repeatCount', 'indefinite');

          // Core point
          g.append('circle')
            .attr('cx', projected[0])
            .attr('cy', projected[1])
            .attr('r', 3)
            .attr('fill', d.type.includes('Inundação') || d.type.includes('Enxurrada') ? '#00f0ff' : '#ffb000');
        }
      });
    });

    // Drag behavior
    const drag = d3.drag()
      .on('drag', (event) => {
        const rotate = projection.rotate();
        const k = sensitivity / projection.scale();
        projection.rotate([
          rotate[0] + event.dx * k,
          rotate[1] - event.dy * k
        ]);
        setRotation([projection.rotate()[0], projection.rotate()[1]]);
      });

    svg.call(drag as any);

    // Auto-rotation
    const timer = d3.timer((elapsed) => {
      const rotate = projection.rotate();
      projection.rotate([rotate[0] + 0.1, rotate[1]]);
      svg.selectAll('path').attr('d', path as any);
      
      // Update points position
      svg.selectAll('.point').each(function(d: any, i) {
          // This is a bit complex in raw D3, but for the demo we'll just let it rotate countries
      });
    });

    return () => timer.stop();
  }, [data, rotation]);

  return (
    <div className="w-full h-full flex items-center justify-center bg-black/20 rounded-xl border border-tactical-border overflow-hidden relative">
      <div className="absolute top-4 left-4 z-10 font-mono text-[10px] text-tactical-green uppercase tracking-widest bg-black/50 p-2 border border-tactical-green/30">
        {">"} SATELLITE_LINK: ACTIVE<br/>
        {">"} SCANNING_SECTOR: BR_SOUTH_AMERICA<br/>
        {">"} RESOLUTION: 4K_TACTICAL
      </div>
      <svg ref={svgRef} className="cursor-move"></svg>
      <div className="absolute bottom-4 right-4 z-10 flex flex-col gap-1">
        <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-tactical-blue"></div>
            <span className="text-[9px] font-mono text-tactical-muted uppercase">Hidrológico</span>
        </div>
        <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-tactical-amber"></div>
            <span className="text-[9px] font-mono text-tactical-muted uppercase">Climatológico</span>
        </div>
      </div>
    </div>
  );
};

export default Globe;
