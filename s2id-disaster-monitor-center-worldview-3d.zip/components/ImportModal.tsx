import React, { useState } from 'react';
import { X, UploadCloud, FileText, AlertCircle, ArrowRight, Terminal, Copy, Check } from 'lucide-react';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (rawText: string) => Promise<void>;
}

const PUPPETEER_SCRIPT = `
/**
 * S2ID SCRAPER AUTOMATIZADO (Rodar localmente)
 * 
 * 1. Instale o Node.js
 * 2. Crie uma pasta e rode: npm init -y
 * 3. Instale dependências: npm install puppeteer
 * 4. Salve este arquivo como: scraper.js
 * 5. Execute: node scraper.js
 */

const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
  console.log('🚀 Iniciando navegador...');
  const browser = await puppeteer.launch({ headless: "new" });
  const page = await browser.newPage();

  console.log('🌍 Acessando S2ID...');
  // Acessa a página de relatórios públicos
  await page.goto('https://s2id.mi.gov.br/paginas/relatorios/', { waitUntil: 'networkidle2' });

  // Exemplo: Extrair dados da tabela principal ou do corpo da página
  // Aqui pegamos o texto visível que a IA do dashboard vai estruturar
  const content = await page.evaluate(() => {
    return document.body.innerText;
  });

  console.log('💾 Salvando dados...');
  const output = {
    capturedAt: new Date().toISOString(),
    rawContent: content
  };

  fs.writeFileSync('dados_s2id.json', JSON.stringify(output, null, 2));
  
  console.log('✅ Sucesso! Arquivo "dados_s2id.json" gerado.');
  console.log('👉 Agora arraste este arquivo para o Dashboard.');

  await browser.close();
})();
`;

const ImportModal: React.FC<ImportModalProps> = ({ isOpen, onClose, onImport }) => {
  const [activeTab, setActiveTab] = useState<'manual' | 'auto'>('manual');
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyScript = () => {
    navigator.clipboard.writeText(PUPPETEER_SCRIPT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const content = event.target?.result as string;
        // Try to parse just to see if it's the JSON from our script
        try {
            const json = JSON.parse(content);
            if (json.rawContent) {
                setInputText(json.rawContent);
            } else {
                setInputText(content); // fallback
            }
        } catch {
            setInputText(content); // Plain text file
        }
        // Auto submit if file is loaded? No, let user confirm.
        setError(null);
      } catch (err) {
        setError("Erro ao ler arquivo.");
      }
    };
    reader.readAsText(file);
  };

  const handleSubmit = async () => {
    if (!inputText.trim()) {
      setError("Nenhum dado encontrado para processar.");
      return;
    }
    
    setIsProcessing(true);
    setError(null);
    try {
      await onImport(inputText);
      setInputText('');
      onClose();
    } catch (e) {
      setError("Falha ao processar. Verifique se os dados são do S2ID.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto font-mono" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        
        <div className="fixed inset-0 bg-black bg-opacity-90 transition-opacity backdrop-blur-sm" onClick={onClose} aria-hidden="true"></div>
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div className="inline-block align-bottom bg-tactical-panel border border-tactical-green text-left overflow-hidden shadow-[0_0_30px_rgba(0,255,65,0.15)] transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full relative">
          
          {/* Corner Accents */}
          <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-tactical-green"></div>
          <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-tactical-green"></div>
          <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-tactical-green"></div>
          <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-tactical-green"></div>

          {/* Header */}
          <div className="bg-black/80 px-4 py-4 sm:px-6 border-b border-tactical-border flex justify-between items-center">
            <h3 className="text-sm leading-6 font-bold text-tactical-green uppercase tracking-widest flex items-center gap-2">
              <Terminal className="w-5 h-5" />
              Interface de Upload S2ID
            </h3>
            <button onClick={onClose} className="text-tactical-muted hover:text-tactical-red transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tabs */}
          <div className="border-b border-tactical-border bg-black/50">
            <nav className="-mb-px flex px-6" aria-label="Tabs">
              <button
                onClick={() => setActiveTab('manual')}
                className={`${
                  activeTab === 'manual'
                    ? 'border-tactical-green text-tactical-green bg-tactical-green/10'
                    : 'border-transparent text-tactical-muted hover:text-white hover:border-tactical-border'
                } w-1/2 py-4 px-1 text-center border-b-2 font-medium text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors`}
              >
                <FileText className="w-4 h-4" />
                Input Manual
              </button>
              <button
                onClick={() => setActiveTab('auto')}
                className={`${
                  activeTab === 'auto'
                    ? 'border-tactical-green text-tactical-green bg-tactical-green/10'
                    : 'border-transparent text-tactical-muted hover:text-white hover:border-tactical-border'
                } w-1/2 py-4 px-1 text-center border-b-2 font-medium text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors`}
              >
                <Terminal className="w-4 h-4" />
                Script de Extração
              </button>
            </nav>
          </div>

          <div className="px-4 py-5 sm:p-6 bg-tactical-panel">
            
            {activeTab === 'manual' ? (
              <div className="space-y-4">
                <div className="bg-tactical-blue/10 border border-tactical-blue/30 rounded-none p-4">
                  <p className="text-xs text-tactical-blue uppercase tracking-wider">
                    <strong className="text-tactical-blue font-bold">{">"} INSTRUÇÕES:</strong> Cole o payload de dados brutos (Ctrl+A, Ctrl+C no S2ID) na área abaixo para processamento.
                  </p>
                </div>
                <textarea
                  className="w-full h-48 p-3 bg-black border border-tactical-border text-tactical-green focus:ring-1 focus:ring-tactical-green focus:border-tactical-green sm:text-xs font-mono resize-none"
                  placeholder="> AGUARDANDO INPUT DE DADOS..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                ></textarea>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-black border border-tactical-border p-4 relative group">
                  <div className="absolute top-2 right-2">
                    <button 
                        onClick={handleCopyScript}
                        className="bg-tactical-border hover:bg-tactical-muted text-white p-1.5 transition-colors"
                        title="Copiar script"
                    >
                        {copied ? <Check className="w-4 h-4 text-tactical-green" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <pre className="text-[10px] text-tactical-green font-mono overflow-x-auto p-2 h-32 scrollbar-thin">
                    {PUPPETEER_SCRIPT}
                  </pre>
                </div>
                
                <div className="text-center py-6 border-2 border-dashed border-tactical-border bg-black/50 hover:bg-tactical-border/20 transition-colors cursor-pointer relative">
                    <input 
                        type="file" 
                        accept=".json,.txt"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        onChange={handleFileUpload}
                    />
                    <div className="pointer-events-none">
                        <UploadCloud className={`mx-auto h-8 w-8 ${inputText ? 'text-tactical-green' : 'text-tactical-muted'}`} />
                        <p className={`mt-2 text-xs uppercase tracking-widest ${inputText ? 'text-tactical-green' : 'text-tactical-muted'}`}>
                           {inputText ? '> PAYLOAD CARREGADO. PRONTO PARA PROCESSAR.' : '> UPLOAD DE ARQUIVO JSON/TXT'}
                        </p>
                    </div>
                </div>
              </div>
            )}

            {error && (
              <div className="mt-4 bg-tactical-red/10 border border-tactical-red/30 p-3 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-tactical-red mt-0.5" />
                <p className="text-xs text-tactical-red uppercase tracking-wider">{error}</p>
              </div>
            )}
          </div>

          <div className="bg-black/80 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse border-t border-tactical-border">
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isProcessing || !inputText}
              className={`w-full inline-flex justify-center border border-tactical-green shadow-[0_0_10px_rgba(0,255,65,0.2)] px-4 py-2 bg-tactical-green/10 text-xs font-bold text-tactical-green uppercase tracking-widest hover:bg-tactical-green hover:text-black focus:outline-none sm:ml-3 sm:w-auto transition-all ${isProcessing || !inputText ? 'opacity-50 cursor-not-allowed hover:bg-tactical-green/10 hover:text-tactical-green' : ''}`}
            >
              {isProcessing ? '> PROCESSANDO...' : `> EXECUTAR`}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="mt-3 w-full inline-flex justify-center border border-tactical-border px-4 py-2 bg-black text-xs font-bold text-tactical-muted uppercase tracking-widest hover:bg-tactical-border hover:text-white focus:outline-none sm:mt-0 sm:ml-3 sm:w-auto transition-colors"
            >
              CANCELAR
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImportModal;