import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  color: string;
  subtext?: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon, color, subtext }) => {
  return (
    <div className={`bg-tactical-panel/80 backdrop-blur-md p-3 border ${color} relative overflow-hidden group shadow-lg`}>
      {/* Corner Accents */}
      <div className={`absolute top-0 left-0 w-1.5 h-1.5 border-t border-l ${color.replace('text-', 'border-')}`}></div>
      <div className={`absolute top-0 right-0 w-1.5 h-1.5 border-t border-r ${color.replace('text-', 'border-')}`}></div>
      
      <div className="flex items-center justify-between relative z-10 gap-4">
        <div>
          <p className="text-[8px] font-mono font-bold text-tactical-muted mb-0.5 uppercase tracking-widest">{title}</p>
          <h3 className={`text-xl font-display tracking-wider ${color.split(' ')[0]}`}>{value}</h3>
        </div>
        <div className={`p-1.5 border border-dashed ${color.replace('text-', 'border-').split(' ')[0]} bg-black/50`}>
          <Icon className={`w-4 h-4 ${color.split(' ')[0]}`} />
        </div>
      </div>
    </div>
  );
};

export default StatCard;