import React from 'react';
import { DisasterDecree } from '../types';
import { AlertTriangle, CheckCircle, Clock, FileText, Crosshair } from 'lucide-react';

interface DisasterTableProps {
  decrees: DisasterDecree[];
}

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  let colorClass = "border-tactical-muted text-tactical-muted";
  let Icon = Clock;

  if (status.toLowerCase().includes("homologado") || status.toLowerCase().includes("reconhecido")) {
    colorClass = "border-tactical-green text-tactical-green bg-tactical-green/10";
    Icon = CheckCircle;
  } else if (status.toLowerCase().includes("análise")) {
    colorClass = "border-tactical-amber text-tactical-amber bg-tactical-amber/10";
    Icon = Clock;
  } else if (status.toLowerCase().includes("arquivado") || status.toLowerCase().includes("devolvido")) {
    colorClass = "border-tactical-red text-tactical-red bg-tactical-red/10";
    Icon = AlertTriangle;
  }

  return (
    <span className={`inline-flex items-center px-2 py-1 border text-[10px] font-mono uppercase tracking-wider ${colorClass}`}>
      <Icon className="w-3 h-3 mr-1.5" />
      {status}
    </span>
  );
};

const DisasterTable: React.FC<DisasterTableProps> = ({ decrees }) => {
  return (
    <div className="bg-tactical-panel border border-tactical-border relative">
      {/* Corner Accents */}
      <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-tactical-muted"></div>
      <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-tactical-muted"></div>
      <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-tactical-muted"></div>
      <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-tactical-muted"></div>

      <div className="px-4 py-3 border-b border-tactical-border flex justify-between items-center bg-black/50">
        <h3 className="text-xs font-mono uppercase tracking-widest text-white flex items-center gap-2">
          <Crosshair className="w-4 h-4 text-tactical-blue" />
          Log de Ocorrências [S2ID]
        </h3>
        <span className="text-[10px] font-mono text-tactical-muted uppercase">[{decrees.length} REGISTROS]</span>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-tactical-border font-mono text-xs">
          <thead className="bg-black/80">
            <tr>
              <th scope="col" className="px-4 py-3 text-left text-[10px] text-tactical-muted uppercase tracking-widest">
                Localidade
              </th>
              <th scope="col" className="px-4 py-3 text-left text-[10px] text-tactical-muted uppercase tracking-widest">
                Classificação
              </th>
              <th scope="col" className="px-4 py-3 text-left text-[10px] text-tactical-muted uppercase tracking-widest">
                Timestamp
              </th>
              <th scope="col" className="px-4 py-3 text-left text-[10px] text-tactical-muted uppercase tracking-widest">
                Impacto
              </th>
              <th scope="col" className="px-4 py-3 text-left text-[10px] text-tactical-muted uppercase tracking-widest">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-tactical-border/50 bg-tactical-panel">
            {decrees.map((decree) => (
              <tr key={decree.id} className="hover:bg-tactical-border/30 transition-colors group">
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="flex items-center">
                    <div>
                      <div className="text-tactical-text font-bold group-hover:text-tactical-blue transition-colors">{decree.municipality}</div>
                      <div className="text-[10px] text-tactical-muted">{decree.uf}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="text-tactical-text truncate max-w-[200px]" title={decree.type}>{decree.type}</div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="text-tactical-muted">{decree.date}</div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-tactical-amber">
                  {decree.affected.toLocaleString('pt-BR')}
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <StatusBadge status={decree.status} />
                </td>
              </tr>
            ))}
            {decrees.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-12 text-center text-tactical-muted uppercase tracking-widest">
                  {">"} NENHUM DADO ENCONTRADO. INICIE VARREDURA.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DisasterTable;