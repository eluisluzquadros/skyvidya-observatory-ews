import React, { useState, useEffect, useCallback } from 'react';
import { 
  Activity, 
  Map as MapIcon, 
  Users, 
  Search, 
  RefreshCw, 
  AlertOctagon,
  TrendingUp,
  Database,
  Upload,
  Crosshair,
  Terminal,
  MessageSquare,
  Newspaper,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Globe as GlobeIcon
} from 'lucide-react';
import { DisasterDecree, FilterState } from './types';
import { fetchSimulatedData, generateInsight, parseS2IDData, generateNews } from './services/geminiService';
import StatCard from './components/StatCard';
import DisasterTable from './components/DisasterTable';
import { StateImpactChart, TypeDistributionChart } from './components/Charts';
import { BRAZIL_STATES, DISASTER_TYPES } from './constants';
import ImportModal from './components/ImportModal';
import Globe from './components/Globe';
import TacticalChat from './components/TacticalChat';
import TacticalAI from './components/TacticalAI';

const App: React.FC = () => {
  const [data, setData] = useState<DisasterDecree[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [insight, setInsight] = useState<string>("");
  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [filters, setFilters] = useState<FilterState>({ uf: '', type: '' });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [dataSource, setDataSource] = useState<'simulated' | 'real'>('simulated');
  const [leftSidebarOpen, setLeftSidebarOpen] = useState(true);
  const [rightSidebarOpen, setRightSidebarOpen] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState<DisasterDecree | null>(null);
  const [rightTab, setRightTab] = useState<'chat' | 'ai'>('ai');
  const [news, setNews] = useState<string[]>([]);
  const [loadingNews, setLoadingNews] = useState(false);

  const handleEventSelect = async (event: DisasterDecree) => {
    setSelectedEvent(event);
    setLoadingNews(true);
    setNews([]);
    try {
        const headlines = await generateNews(event);
        setNews(headlines);
    } catch (error) {
        console.error(error);
    } finally {
        setLoadingNews(false);
    }
  };

  const loadSimulatedData = useCallback(async () => {
    setLoading(true);
    setInsight("");
    setDataSource('simulated');
    try {
      const result = await fetchSimulatedData();
      setData(result);
      
      setAnalyzing(true);
      const aiInsight = await generateInsight(result);
      setInsight(aiInsight);
    } catch (error) {
      console.error(error);
      alert("Erro ao conectar com a API de simulação. Verifique a chave de API.");
    } finally {
      setLoading(false);
      setAnalyzing(false);
    }
  }, []);

  const handleRealDataImport = async (rawText: string) => {
    setLoading(true);
    setInsight("");
    try {
      const result = await parseS2IDData(rawText);
      setData(result);
      setDataSource('real');

      setAnalyzing(true);
      const aiInsight = await generateInsight(result);
      setInsight(aiInsight);
    } catch (error) {
      console.error(error);
      throw error;
    } finally {
      setLoading(false);
      setAnalyzing(false);
    }
  };

  useEffect(() => {
    loadSimulatedData();
  }, []);

  const filteredData = data.filter(item => {
    const matchUf = filters.uf ? item.uf === filters.uf : true;
    const matchType = filters.type ? item.type === filters.type : true;
    return matchUf && matchType;
  });

  const totalDecrees = filteredData.length;
  const totalAffected = filteredData.reduce((acc, curr) => acc + curr.affected, 0);
  const activeEvents = filteredData.filter(d => d.status.includes('Análise') || d.status.includes('Reconhecido')).length;

  return (
    <div className="h-screen bg-tactical-bg text-tactical-text font-sans selection:bg-tactical-green selection:text-black flex flex-col overflow-hidden">
      <ImportModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onImport={handleRealDataImport}
      />

      {/* Navbar */}
      <nav className="border-b border-tactical-border bg-tactical-panel/80 backdrop-blur-md z-50 shrink-0">
        <div className="max-w-full mx-auto px-4">
          <div className="flex justify-between h-14 items-center">
            <div className="flex items-center gap-3">
              <div className="relative flex items-center justify-center w-8 h-8 border border-tactical-border rounded bg-black">
                <Crosshair className="w-5 h-5 text-tactical-green animate-[spin_10s_linear_infinite]" />
              </div>
              <div>
                <h1 className="text-lg font-display font-bold tracking-widest text-white uppercase">S2ID <span className="text-tactical-green">Tactical</span></h1>
              </div>
            </div>
            
            <div className="flex items-center gap-6">
                <div className="hidden md:flex items-center gap-4 font-mono text-[10px] uppercase tracking-tighter">
                    <div className="flex items-center gap-1.5">
                        <span className="text-tactical-muted">Lat:</span>
                        <span className="text-tactical-green">-23.5505</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                        <span className="text-tactical-muted">Lng:</span>
                        <span className="text-tactical-green">-46.6333</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                        <span className="text-tactical-muted">Alt:</span>
                        <span className="text-tactical-blue">4200M</span>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <button 
                        onClick={() => setIsModalOpen(true)}
                        className="flex items-center gap-2 border border-tactical-green/50 text-tactical-green hover:bg-tactical-green hover:text-black px-3 py-1.5 rounded text-[10px] font-mono uppercase transition-all"
                    >
                        <Terminal className="w-3 h-3" />
                        <span>Import</span>
                    </button>
                    <button 
                        onClick={loadSimulatedData}
                        disabled={loading}
                        className="border border-tactical-border bg-tactical-panel hover:bg-tactical-border px-3 py-1.5 rounded text-[10px] font-mono uppercase transition-colors disabled:opacity-50 text-tactical-muted hover:text-white"
                    >
                        <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin text-tactical-blue' : ''}`} />
                    </button>
                </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="flex-grow flex overflow-hidden relative">
        {/* Left Sidebar: Tactical Feed */}
        <aside className={`${leftSidebarOpen ? 'w-80' : 'w-0'} transition-all duration-300 border-r border-tactical-border bg-tactical-panel/50 backdrop-blur-sm flex flex-col relative z-30`}>
            <button 
                onClick={() => setLeftSidebarOpen(!leftSidebarOpen)}
                className="absolute -right-6 top-1/2 -translate-y-1/2 bg-tactical-panel border border-l-0 border-tactical-border p-1 text-tactical-muted hover:text-white transition-colors"
            >
                {leftSidebarOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            
            <div className="p-4 border-b border-tactical-border flex items-center justify-between bg-black/40">
                <div className="flex items-center gap-2">
                    <Newspaper className="w-4 h-4 text-tactical-amber" />
                    <h2 className="text-[10px] font-mono uppercase tracking-widest text-tactical-amber font-bold">Tactical Feed</h2>
                </div>
                <span className="text-[9px] font-mono text-tactical-muted">LIVE_STREAM</span>
            </div>

            <div className="flex-grow overflow-y-auto p-4 space-y-4 scrollbar-thin">
                {filteredData.map((item) => (
                    <div 
                        key={item.id} 
                        onClick={() => handleEventSelect(item)}
                        className={`p-3 border border-tactical-border bg-black/30 hover:bg-tactical-border/20 transition-all cursor-pointer group relative ${selectedEvent?.id === item.id ? 'border-tactical-green bg-tactical-green/5' : ''}`}
                    >
                        <div className="flex justify-between items-start mb-2">
                            <span className="text-[9px] font-mono text-tactical-muted">{item.date}</span>
                            <ShieldCheck className={`w-3 h-3 ${item.status.includes('Reconhecido') ? 'text-tactical-green' : 'text-tactical-amber'}`} />
                        </div>
                        <h4 className="text-xs font-bold text-white mb-1 group-hover:text-tactical-blue transition-colors">{item.municipality} - {item.uf}</h4>
                        <p className="text-[10px] text-tactical-muted uppercase mb-2">{item.type}</p>
                        <div className="flex items-center justify-between">
                            <span className="text-[9px] font-mono text-tactical-red">AFETADOS: {item.affected}</span>
                            <span className="text-[8px] font-mono text-tactical-muted border border-tactical-border px-1">S2ID_REF</span>
                        </div>
                    </div>
                ))}
            </div>
        </aside>

        {/* Main Content: Map & Stats */}
        <main className="flex-grow relative flex flex-col overflow-hidden">
            {/* Map Background */}
            <div className="absolute inset-0 z-0">
                <Globe data={filteredData} onPointClick={handleEventSelect} />
            </div>

            {/* Top Overlay: Stats */}
            <div className="absolute top-6 left-6 right-6 z-10 grid grid-cols-1 md:grid-cols-3 gap-4 pointer-events-none">
                <div className="pointer-events-auto">
                    <StatCard 
                        title="Registros Ativos" 
                        value={totalDecrees} 
                        icon={MapIcon} 
                        color="text-tactical-blue border-tactical-blue"
                    />
                </div>
                <div className="pointer-events-auto">
                    <StatCard 
                        title="População em Risco" 
                        value={totalAffected.toLocaleString('pt-BR')} 
                        icon={Users} 
                        color="text-tactical-red border-tactical-red"
                    />
                </div>
                <div className="pointer-events-auto">
                    <StatCard 
                        title="Eventos Críticos" 
                        value={activeEvents} 
                        icon={AlertOctagon} 
                        color="text-tactical-amber border-tactical-amber"
                    />
                </div>
            </div>

            {/* Bottom Overlay: Event Detail / Analysis */}
            <div className="absolute bottom-6 left-6 right-6 z-10 flex gap-6 pointer-events-none">
                {selectedEvent && (
                    <div className="w-1/3 bg-tactical-panel/90 backdrop-blur-md border border-tactical-green p-4 pointer-events-auto shadow-[0_0_20px_rgba(0,255,65,0.1)] flex flex-col max-h-[400px]">
                        <div className="flex justify-between items-center mb-4 border-b border-tactical-green/30 pb-2 shrink-0">
                            <h3 className="text-xs font-mono font-bold text-tactical-green uppercase tracking-widest">Detalhes da Ocorrência</h3>
                            <button onClick={() => setSelectedEvent(null)} className="text-tactical-muted hover:text-white"><ChevronLeft className="w-4 h-4 rotate-90" /></button>
                        </div>
                        <div className="overflow-y-auto scrollbar-thin pr-2">
                            <div className="space-y-3 font-mono text-[11px] mb-6">
                                <div className="flex justify-between">
                                    <span className="text-tactical-muted">MUNICÍPIO:</span>
                                    <span className="text-white font-bold">{selectedEvent.municipality}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-tactical-muted">UF:</span>
                                    <span className="text-white">{selectedEvent.uf}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-tactical-muted">TIPO:</span>
                                    <span className="text-tactical-amber">{selectedEvent.type}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-tactical-muted">DATA:</span>
                                    <span className="text-white">{selectedEvent.date}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-tactical-muted">STATUS:</span>
                                    <span className="text-tactical-green">{selectedEvent.status}</span>
                                </div>
                            </div>

                            <div className="border-t border-tactical-border pt-4">
                                <h4 className="text-[10px] font-bold text-tactical-blue uppercase tracking-widest mb-3 flex items-center gap-2">
                                    <Newspaper className="w-3 h-3" /> Notícias Relacionadas
                                </h4>
                                {loadingNews ? (
                                    <div className="flex items-center gap-2 animate-pulse text-tactical-blue text-[10px] font-mono">
                                        <RefreshCw className="w-3 h-3 animate-spin" />
                                        <span>BUSCANDO EVIDÊNCIAS...</span>
                                    </div>
                                ) : (
                                    <div className="space-y-3">
                                        {news.map((n, idx) => (
                                            <div key={idx} className="bg-black/40 border-l-2 border-tactical-blue p-2 text-[10px] font-mono text-tactical-text leading-tight">
                                                {n}
                                            </div>
                                        ))}
                                        {news.length === 0 && (
                                            <p className="text-[10px] font-mono text-tactical-muted italic">{">"} Nenhuma notícia vinculada.</p>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                )}
                
                <div className={`flex-grow bg-tactical-panel/90 backdrop-blur-md border border-tactical-border p-4 pointer-events-auto ${selectedEvent ? 'w-2/3' : 'w-full'}`}>
                    <div className="flex items-center gap-3 mb-4 border-b border-tactical-border pb-2">
                        <TrendingUp className="w-4 h-4 text-tactical-green" />
                        <h3 className="text-xs font-mono uppercase tracking-widest text-tactical-green">Análise de Inteligência</h3>
                    </div>
                    <div className="font-mono text-[11px] leading-relaxed max-h-32 overflow-y-auto scrollbar-thin">
                        {analyzing ? (
                            <div className="flex items-center gap-2 animate-pulse text-tactical-green">
                                <RefreshCw className="w-3 h-3 animate-spin" />
                                <span>PROCESSANDO TELEMETRIA...</span>
                            </div>
                        ) : (
                            insight || `${">"} AGUARDANDO DADOS...`
                        )}
                    </div>
                </div>
            </div>
        </main>

        {/* Right Sidebar: Intelligence Hub / Chat */}
        <aside className={`${rightSidebarOpen ? 'w-80' : 'w-0'} transition-all duration-300 border-l border-tactical-border bg-tactical-panel/50 backdrop-blur-sm flex flex-col relative z-30`}>
            <button 
                onClick={() => setRightSidebarOpen(!rightSidebarOpen)}
                className="absolute -left-6 top-1/2 -translate-y-1/2 bg-tactical-panel border border-r-0 border-tactical-border p-1 text-tactical-muted hover:text-white transition-colors"
            >
                {rightSidebarOpen ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>

            <div className="flex-grow flex flex-col overflow-hidden">
                <div className="h-1/3 flex flex-col border-b border-tactical-border overflow-hidden">
                    <div className="p-3 border-b border-tactical-border bg-black/40 flex items-center gap-2">
                        <GlobeIcon className="w-4 h-4 text-tactical-blue" />
                        <h2 className="text-[10px] font-mono uppercase tracking-widest text-tactical-blue font-bold">Distribuição</h2>
                    </div>
                    <div className="flex-grow p-2 overflow-hidden">
                        <TypeDistributionChart data={filteredData} />
                    </div>
                </div>

                <div className="flex-grow flex flex-col overflow-hidden">
                    <div className="flex border-b border-tactical-border bg-black/20">
                        <button 
                            onClick={() => setRightTab('ai')}
                            className={`flex-1 py-2 text-[10px] font-mono uppercase tracking-widest transition-all border-b-2 ${rightTab === 'ai' ? 'border-tactical-green text-tactical-green bg-tactical-green/5' : 'border-transparent text-tactical-muted hover:text-white'}`}
                        >
                            AI Oracle
                        </button>
                        <button 
                            onClick={() => setRightTab('chat')}
                            className={`flex-1 py-2 text-[10px] font-mono uppercase tracking-widest transition-all border-b-2 ${rightTab === 'chat' ? 'border-tactical-blue text-tactical-blue bg-tactical-blue/5' : 'border-transparent text-tactical-muted hover:text-white'}`}
                        >
                            Comms
                        </button>
                    </div>
                    <div className="flex-grow overflow-hidden">
                        {rightTab === 'ai' ? <TacticalAI context={filteredData} /> : <TacticalChat />}
                    </div>
                </div>
            </div>
        </aside>
      </div>

      {/* Footer / Status Bar */}
      <footer className="h-8 border-t border-tactical-border bg-black px-4 flex items-center justify-between font-mono text-[9px] uppercase tracking-widest z-50 shrink-0">
        <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-tactical-green animate-pulse"></span>
                <span className="text-tactical-green">System_Online</span>
            </div>
            <div className="text-tactical-muted">Uptime: 00:42:12</div>
            <div className="text-tactical-muted">Packet_Loss: 0%</div>
        </div>
        <div className="flex items-center gap-4">
            <div className="text-tactical-blue">S2ID_API: CONNECTED</div>
            <div className="text-tactical-amber">GEMINI_CORE: READY</div>
        </div>
      </footer>
    </div>
  );
};

export default App;