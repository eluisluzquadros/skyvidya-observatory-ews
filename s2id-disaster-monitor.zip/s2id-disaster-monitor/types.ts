export interface DisasterDecree {
  id: string;
  municipality: string;
  uf: string;
  type: string; // e.g., "Estiagem", "Enxurrada", "Vendaval"
  date: string;
  status: string; // e.g., "Homologado", "Reconhecido", "Em Análise"
  affected: number;
}

export interface FilterState {
  uf: string;
  type: string;
}

export type DisasterStats = {
  totalDecrees: number;
  totalAffected: number;
  byType: { name: string; value: number }[];
  byState: { name: string; value: number }[];
};