import { GoogleGenAI, Type } from "@google/genai";
import { DisasterDecree } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MOCK_PROMPT = `
  Generate a realistic dataset of 15 to 25 natural disaster decrees (Situação de Emergência or Estado de Calamidade Pública) 
  that would appear on the Brazilian S2ID platform (Sistema Integrado de Informações sobre Desastres).
  
  Focus on recent events in Brazil (2024-2025).
  Include a mix of:
  - "Estiagem" (Drought) in Northeast/South regions.
  - "Enxurrada" (Flash Flood) or "Inundação" (Flood) in South/Southeast.
  - "Incêndio Florestal" (Forest Fire) in Center-West/North.
  
  Use realistic population numbers for "affected".
`;

export const fetchSimulatedData = async (): Promise<DisasterDecree[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: MOCK_PROMPT,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              municipality: { type: Type.STRING },
              uf: { type: Type.STRING },
              type: { type: Type.STRING },
              date: { type: Type.STRING },
              status: { type: Type.STRING },
              affected: { type: Type.INTEGER },
            },
            required: ["id", "municipality", "uf", "type", "date", "status", "affected"],
          },
        },
      },
    });

    const jsonText = response.text;
    if (!jsonText) return [];
    
    return JSON.parse(jsonText) as DisasterDecree[];
  } catch (error) {
    console.error("Failed to fetch simulated data:", error);
    throw error;
  }
};

export const parseS2IDData = async (rawInput: string): Promise<DisasterDecree[]> => {
  try {
    // Check if the input is already valid JSON (e.g. from a pre-processed script)
    try {
        const preParsed = JSON.parse(rawInput);
        if (Array.isArray(preParsed) && preParsed.length > 0 && preParsed[0].municipality) {
            return preParsed as DisasterDecree[];
        }
    } catch (e) {
        // Not JSON, continue to AI parsing
    }

    const prompt = `
      You are a specialized data scraper and parser for the Brazilian Civil Defense system (S2ID).
      
      Your task is to extract structured data from the following RAW TEXT (which may be copied from an HTML table, a CSV, or a PDF report).
      
      Map the data to this specific JSON structure:
      - id: Generate a unique hash or ID based on municipality and date.
      - municipality: The name of the city/municipality.
      - uf: The 2-letter state code (e.g., SC, BA, SP).
      - type: The disaster type (e.g., Estiagem, Enxurrada, Vendaval).
      - date: The date of occurrence or recognition (format DD/MM/YYYY).
      - status: The status (e.g., "Homologado", "Em Análise", "Reconhecido").
      - affected: The number of affected people. If not explicitly found, estimate based on context or set to 0.

      Raw Input Data:
      """
      ${rawInput.substring(0, 50000)} 
      """
      
      Strictly return a JSON Array. Clean up encoding issues.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              municipality: { type: Type.STRING },
              uf: { type: Type.STRING },
              type: { type: Type.STRING },
              date: { type: Type.STRING },
              status: { type: Type.STRING },
              affected: { type: Type.INTEGER },
            },
            required: ["id", "municipality", "uf", "type", "date", "status", "affected"],
          },
        },
      },
    });

    const jsonText = response.text;
    if (!jsonText) return [];

    return JSON.parse(jsonText) as DisasterDecree[];
  } catch (error) {
    console.error("Failed to parse S2ID data:", error);
    throw new Error("Não foi possível processar os dados colados. Verifique se o texto contém informações válidas do S2ID.");
  }
};

export const generateInsight = async (data: DisasterDecree[]): Promise<string> => {
    try {
        const dataSummary = JSON.stringify(data.slice(0, 30)); // Analyze top 30 items
        const prompt = `
            Analyze this JSON data of Brazilian disaster decrees.
            Provide a concise, 2-paragraph executive summary in Portuguese (pt-BR).
            Highlight the most critical region/state, the predominant type of disaster, and anomalies (like huge affected populations).
            Make it sound like a formal Civil Defense intelligence report.
            Data: ${dataSummary}
        `;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });

        return response.text || "Não foi possível gerar uma análise no momento.";
    } catch (error) {
        console.error("Error generating insight:", error);
        return "Erro ao gerar análise de inteligência.";
    }
}