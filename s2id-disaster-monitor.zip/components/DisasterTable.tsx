import React from 'react';
import { DisasterDecree } from '../types';
import { AlertTriangle, CheckCircle, Clock, FileText } from 'lucide-react';

interface DisasterTableProps {
  decrees: DisasterDecree[];
}

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  let colorClass = "bg-gray-100 text-gray-800";
  let Icon = Clock;

  if (status.toLowerCase().includes("homologado") || status.toLowerCase().includes("reconhecido")) {
    colorClass = "bg-green-100 text-green-800";
    Icon = CheckCircle;
  } else if (status.toLowerCase().includes("análise")) {
    colorClass = "bg-yellow-100 text-yellow-800";
    Icon = Clock;
  } else if (status.toLowerCase().includes("arquivado") || status.toLowerCase().includes("devolvido")) {
    colorClass = "bg-red-100 text-red-800";
    Icon = AlertTriangle;
  }

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${colorClass}`}>
      <Icon className="w-3 h-3 mr-1" />
      {status}
    </span>
  );
};

const DisasterTable: React.FC<DisasterTableProps> = ({ decrees }) => {
  return (
    <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
        <h3 className="text-lg font-medium text-gray-900 flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-600" />
          Registros Recentes (S2ID)
        </h3>
        <span className="text-sm text-gray-500">{decrees.length} registros encontrados</span>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Município / UF
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Tipo de Desastre
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Data
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Afetados
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {decrees.map((decree) => (
              <tr key={decree.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{decree.municipality}</div>
                      <div className="text-sm text-gray-500">{decree.uf}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{decree.type}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{decree.date}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {decree.affected.toLocaleString('pt-BR')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <StatusBadge status={decree.status} />
                </td>
              </tr>
            ))}
            {decrees.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                  Nenhum dado disponível. Clique em "Atualizar Dados" para simular uma busca.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DisasterTable;