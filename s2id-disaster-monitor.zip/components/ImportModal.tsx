import React, { useState } from 'react';
import { X, UploadCloud, FileText, AlertCircle, ArrowRight, Terminal, Copy, Check } from 'lucide-react';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (rawText: string) => Promise<void>;
}

const PUPPETEER_SCRIPT = `
/**
 * S2ID SCRAPER AUTOMATIZADO (Rodar localmente)
 * 
 * 1. Instale o Node.js
 * 2. Crie uma pasta e rode: npm init -y
 * 3. Instale dependências: npm install puppeteer
 * 4. Salve este arquivo como: scraper.js
 * 5. Execute: node scraper.js
 */

const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
  console.log('🚀 Iniciando navegador...');
  const browser = await puppeteer.launch({ headless: "new" });
  const page = await browser.newPage();

  console.log('🌍 Acessando S2ID...');
  // Acessa a página de relatórios públicos
  await page.goto('https://s2id.mi.gov.br/paginas/relatorios/', { waitUntil: 'networkidle2' });

  // Exemplo: Extrair dados da tabela principal ou do corpo da página
  // Aqui pegamos o texto visível que a IA do dashboard vai estruturar
  const content = await page.evaluate(() => {
    return document.body.innerText;
  });

  console.log('💾 Salvando dados...');
  const output = {
    capturedAt: new Date().toISOString(),
    rawContent: content
  };

  fs.writeFileSync('dados_s2id.json', JSON.stringify(output, null, 2));
  
  console.log('✅ Sucesso! Arquivo "dados_s2id.json" gerado.');
  console.log('👉 Agora arraste este arquivo para o Dashboard.');

  await browser.close();
})();
`;

const ImportModal: React.FC<ImportModalProps> = ({ isOpen, onClose, onImport }) => {
  const [activeTab, setActiveTab] = useState<'manual' | 'auto'>('manual');
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyScript = () => {
    navigator.clipboard.writeText(PUPPETEER_SCRIPT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const content = event.target?.result as string;
        // Try to parse just to see if it's the JSON from our script
        try {
            const json = JSON.parse(content);
            if (json.rawContent) {
                setInputText(json.rawContent);
            } else {
                setInputText(content); // fallback
            }
        } catch {
            setInputText(content); // Plain text file
        }
        // Auto submit if file is loaded? No, let user confirm.
        setError(null);
      } catch (err) {
        setError("Erro ao ler arquivo.");
      }
    };
    reader.readAsText(file);
  };

  const handleSubmit = async () => {
    if (!inputText.trim()) {
      setError("Nenhum dado encontrado para processar.");
      return;
    }
    
    setIsProcessing(true);
    setError(null);
    try {
      await onImport(inputText);
      setInputText('');
      onClose();
    } catch (e) {
      setError("Falha ao processar. Verifique se os dados são do S2ID.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        
        <div className="fixed inset-0 bg-gray-900 bg-opacity-75 transition-opacity backdrop-blur-sm" onClick={onClose} aria-hidden="true"></div>
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div className="inline-block align-bottom bg-white rounded-xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full">
          
          {/* Header */}
          <div className="bg-gray-50 px-4 py-4 sm:px-6 border-b border-gray-200 flex justify-between items-center">
            <h3 className="text-lg leading-6 font-semibold text-gray-900 flex items-center gap-2">
              <UploadCloud className="w-5 h-5 text-blue-600" />
              Importar Dados S2ID
            </h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-500 transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex px-6" aria-label="Tabs">
              <button
                onClick={() => setActiveTab('manual')}
                className={`${
                  activeTab === 'manual'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm flex items-center justify-center gap-2`}
              >
                <FileText className="w-4 h-4" />
                Manual (Copiar/Colar)
              </button>
              <button
                onClick={() => setActiveTab('auto')}
                className={`${
                  activeTab === 'auto'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm flex items-center justify-center gap-2`}
              >
                <Terminal className="w-4 h-4" />
                Automação Local (Script)
              </button>
            </nav>
          </div>

          <div className="px-4 py-5 sm:p-6">
            
            {activeTab === 'manual' ? (
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-100 rounded-md p-4">
                  <p className="text-sm text-blue-800">
                    <strong>Como usar:</strong> Vá até a página de relatórios do S2ID, selecione o conteúdo da tabela (Ctrl+A, Ctrl+C) e cole abaixo.
                  </p>
                </div>
                <textarea
                  className="w-full h-48 p-3 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-xs font-mono"
                  placeholder="Cole aqui o conteúdo copiado do S2ID..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                ></textarea>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-gray-900 rounded-lg p-4 relative group">
                  <div className="absolute top-2 right-2">
                    <button 
                        onClick={handleCopyScript}
                        className="bg-white/10 hover:bg-white/20 text-white p-1.5 rounded-md transition-colors"
                        title="Copiar script"
                    >
                        {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <pre className="text-xs text-green-400 font-mono overflow-x-auto p-2 h-32 scrollbar-thin">
                    {PUPPETEER_SCRIPT}
                  </pre>
                </div>
                
                <div className="text-center py-4 border-2 border-dashed border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer relative">
                    <input 
                        type="file" 
                        accept=".json,.txt"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        onChange={handleFileUpload}
                    />
                    <div className="pointer-events-none">
                        <UploadCloud className="mx-auto h-8 w-8 text-gray-400" />
                        <p className="mt-1 text-sm text-gray-600">
                           {inputText ? 'Arquivo carregado! Clique em Processar.' : 'Arraste o arquivo "dados_s2id.json" gerado pelo script aqui'}
                        </p>
                    </div>
                </div>
              </div>
            )}

            {error && (
              <div className="mt-4 bg-red-50 border border-red-200 rounded-md p-3 flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}
          </div>

          <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isProcessing || !inputText}
              className={`w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm ${isProcessing || !inputText ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isProcessing ? 'Processando...' : `Processar ${activeTab === 'auto' ? 'Arquivo' : 'Texto'}`}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
            >
              Cancelar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImportModal;