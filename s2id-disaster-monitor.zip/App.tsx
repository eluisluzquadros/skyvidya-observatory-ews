import React, { useState, useEffect, useCallback } from 'react';
import { 
  Activity, 
  Map as MapIcon, 
  Users, 
  Search, 
  RefreshCw, 
  AlertOctagon,
  TrendingUp,
  Database,
  Upload
} from 'lucide-react';
import { DisasterDecree, FilterState } from './types';
import { fetchSimulatedData, generateInsight, parseS2IDData } from './services/geminiService';
import StatCard from './components/StatCard';
import DisasterTable from './components/DisasterTable';
import { StateImpactChart, TypeDistributionChart } from './components/Charts';
import { BRAZIL_STATES, DISASTER_TYPES } from './constants';
import ImportModal from './components/ImportModal';

const App: React.FC = () => {
  const [data, setData] = useState<DisasterDecree[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [insight, setInsight] = useState<string>("");
  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [filters, setFilters] = useState<FilterState>({ uf: '', type: '' });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [dataSource, setDataSource] = useState<'simulated' | 'real'>('simulated');

  const loadSimulatedData = useCallback(async () => {
    setLoading(true);
    setInsight("");
    setDataSource('simulated');
    try {
      const result = await fetchSimulatedData();
      setData(result);
      
      setAnalyzing(true);
      const aiInsight = await generateInsight(result);
      setInsight(aiInsight);
    } catch (error) {
      console.error(error);
      alert("Erro ao conectar com a API de simulação. Verifique a chave de API.");
    } finally {
      setLoading(false);
      setAnalyzing(false);
    }
  }, []);

  const handleRealDataImport = async (rawText: string) => {
    setLoading(true);
    setInsight("");
    try {
      const result = await parseS2IDData(rawText);
      setData(result);
      setDataSource('real');

      setAnalyzing(true);
      const aiInsight = await generateInsight(result);
      setInsight(aiInsight);
    } catch (error) {
      console.error(error);
      throw error; // Re-throw to be caught by modal
    } finally {
      setLoading(false);
      setAnalyzing(false);
    }
  };

  // Load initial simulated data
  useEffect(() => {
    loadSimulatedData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Filter Logic
  const filteredData = data.filter(item => {
    const matchUf = filters.uf ? item.uf === filters.uf : true;
    const matchType = filters.type ? item.type === filters.type : true;
    return matchUf && matchType;
  });

  // Metrics
  const totalDecrees = filteredData.length;
  const totalAffected = filteredData.reduce((acc, curr) => acc + curr.affected, 0);
  const activeEvents = filteredData.filter(d => d.status.includes('Análise') || d.status.includes('Reconhecido')).length;

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans">
      <ImportModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onImport={handleRealDataImport}
      />

      {/* Navbar */}
      <nav className="bg-blue-900 text-white shadow-lg sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-3">
              <div className="bg-white/10 p-2 rounded-lg">
                <Activity className="w-6 h-6 text-yellow-400" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">S2ID Monitor</h1>
                <p className="text-xs text-blue-200">Painel de Inteligência Civil</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
               <button 
                onClick={() => setIsModalOpen(true)}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-500 px-4 py-2 rounded-md text-sm font-medium transition-colors shadow-sm"
              >
                <Upload className="w-4 h-4" />
                <span className="hidden sm:inline">Importar S2ID</span>
              </button>
               <button 
                onClick={loadSimulatedData}
                disabled={loading}
                className="flex items-center gap-2 bg-blue-800 hover:bg-blue-700 px-4 py-2 rounded-md text-sm font-medium transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Source Indicator */}
        <div className={`border-l-4 p-4 mb-8 rounded-r-md flex justify-between items-center ${dataSource === 'real' ? 'bg-green-50 border-green-500' : 'bg-blue-50 border-blue-500'}`}>
          <div className="flex">
            <div className="flex-shrink-0">
              <Database className={`h-5 w-5 ${dataSource === 'real' ? 'text-green-500' : 'text-blue-400'}`} aria-hidden="true" />
            </div>
            <div className="ml-3">
              <p className={`text-sm ${dataSource === 'real' ? 'text-green-700' : 'text-blue-700'}`}>
                {dataSource === 'real' ? (
                  <><strong>Dados Reais Importados:</strong> Visualizando dados processados do S2ID via extração inteligente.</>
                ) : (
                  <><strong>Modo Simulação:</strong> Visualizando dados gerados por IA. Clique em <em>Importar S2ID</em> para usar dados reais.</>
                )}
              </p>
            </div>
          </div>
          {dataSource === 'real' && (
            <span className="text-xs bg-green-200 text-green-800 px-2 py-1 rounded-full font-bold">LIVE DATA</span>
          )}
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatCard 
            title="Total de Registros" 
            value={totalDecrees} 
            icon={MapIcon} 
            color="bg-blue-500 text-blue-600"
            subtext={dataSource === 'real' ? "Extraídos do texto" : "Gerados via IA"}
          />
          <StatCard 
            title="Pessoas Afetadas" 
            value={totalAffected.toLocaleString('pt-BR')} 
            icon={Users} 
            color="bg-red-500 text-red-600"
            subtext="Estimativa extraída"
          />
          <StatCard 
            title="Eventos Ativos" 
            value={activeEvents} 
            icon={AlertOctagon} 
            color="bg-yellow-500 text-yellow-600"
            subtext="Em análise ou vigentes"
          />
        </div>

        {/* Analysis Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Charts Column */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Filters */}
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex flex-wrap gap-4 items-center">
              <div className="flex items-center gap-2 text-gray-500">
                <Search className="w-4 h-4" />
                <span className="text-sm font-medium">Filtros:</span>
              </div>
              
              <select 
                value={filters.uf}
                onChange={(e) => setFilters(prev => ({ ...prev, uf: e.target.value }))}
                className="block w-32 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md border"
              >
                <option value="">Todos UFs</option>
                {BRAZIL_STATES.map(uf => <option key={uf} value={uf}>{uf}</option>)}
              </select>

              <select 
                value={filters.type}
                onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
                className="block w-48 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md border"
              >
                <option value="">Todos Tipos</option>
                {DISASTER_TYPES.map(type => <option key={type} value={type}>{type}</option>)}
              </select>

              {(filters.uf || filters.type) && (
                <button 
                  onClick={() => setFilters({ uf: '', type: '' })}
                  className="text-sm text-red-600 hover:text-red-800 font-medium ml-auto"
                >
                  Limpar
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <TypeDistributionChart data={filteredData} />
              <StateImpactChart data={filteredData} />
            </div>
          </div>

          {/* AI Insight Column */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-indigo-100 overflow-hidden h-full flex flex-col">
              <div className="bg-indigo-900 px-6 py-4 flex items-center gap-3 shrink-0">
                <TrendingUp className="w-5 h-5 text-indigo-300" />
                <h3 className="text-lg font-medium text-white">
                  Análise de Inteligência {dataSource === 'real' ? '(Real)' : '(Simulada)'}
                </h3>
              </div>
              <div className="p-6 flex-grow">
                {analyzing ? (
                  <div className="flex flex-col items-center justify-center h-full space-y-4 min-h-[200px]">
                    <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                    <p className="text-sm text-gray-500 animate-pulse">
                      {dataSource === 'real' ? 'Analisando dados importados...' : 'Processando cenário...'}
                    </p>
                  </div>
                ) : (
                  <div className="prose prose-sm prose-indigo text-gray-600 h-full flex flex-col">
                    <div className="whitespace-pre-wrap flex-grow">{insight}</div>
                    <div className="mt-6 pt-4 border-t border-gray-100 shrink-0">
                      <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Monitoramento</h4>
                      <p className="text-xs text-gray-500 italic">
                        Relatório gerado automaticamente via Gemini 2.5 Flash baseado nos dados {dataSource === 'real' ? 'extraídos do S2ID' : 'simulados'}.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Data List */}
        <DisasterTable decrees={filteredData} />

      </main>
    </div>
  );
};

export default App;